import RegistrationForm from './component/form';
import './App.css';

function App() {
  return (
    <RegistrationForm/>
  );
}

export default App;
